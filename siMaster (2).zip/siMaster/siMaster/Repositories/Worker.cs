﻿using GreenPipes;
using MassTransit;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;
using siMaster.Header;
using siMaster.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace siMaster.Repositories
{
    public class Worker : IWorker
    {
        readonly IConfiguration configuration;
        IRequestClient<FundtransferReq> _client;
        private List<string> Urls = new List<string> { "www.google.com", "www.facebook.com" };
        public Worker(IConfiguration _configuration, IServiceScopeFactory factory)
        {
            configuration = _configuration;
            _client = factory.CreateScope().ServiceProvider.GetRequiredService<IRequestClient<FundtransferReq>>();//client;
        }

        public async Task DoWork(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await SIrecordSets();
                await Task.Delay(1000 * 5);
            }
        }

        private async Task SIrecordSets()
        {
            var tasks = new List<Task>();
            foreach (var url in Urls)
            {
                tasks.Add(PollUrl(url));
            }
            await Task.WhenAll(tasks);
        }


        private async Task PollUrl(string url)
        {

            FundTranferRequest req = new();
            FundtransferRes res = new();
            CHeader postHeader = new CHeader();

            try
            {
                var newReq = new FundtransferReq
                {
                    //cif = req.cif,
                    //debitAccount = req.sourceAccountNumber ?? "",
                    //creditAccount = req.creditAccountNumber ?? "",
                    //debitTranParticular = req.sourceTrnParticular ?? "",
                    //debitTranParticular2 = req.sourceTrnParticular ?? "",
                    //creditTranParticular = req.payeeTrnParticular ?? "",
                    //creditTranParticular2 = req.payeeTrnParticular ?? "",
                    //amount = Convert.ToDouble(req.amount),
                    //chargeAmount = Convert.ToDouble(req.serviceCharge),
                    //ccy = req.currencyCode ?? "",
                    //debitTranRmks = req.remarks ?? "",
                    //creditTranRmks = req.remarks ?? "",
                    //tranCode = req.tranCode ?? "",
                    //tranType = req.tranType ?? "",
                    //schmType = req.schmType ?? "",
                    //billerCode = "",
                    //billerReference = ""

                };
              //  res = await internalTransfers(newReq, postHeader);

            }
            catch (Exception ex)
            {
                //_logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);

            }

        }


        //public async Task<FundtransferRes> internalTransfers(FundtransferReq newReq, CHeader cHeader)
        //{
        //    FundtransferRes res = new();
        //    res.Status = "001";
        //    res.Message = "Error";
        //    try
        //    {
        //        using (var request = _client.Create(newReq))
        //        {
        //            request.UseExecute(x => x.Headers.Set("uuid", cHeader.uuid));
        //            request.UseExecute(x => x.Headers.Set("username", cHeader.username));
        //            request.UseExecute(x => x.Headers.Set("channel", cHeader.channel));
        //            request.UseExecute(x => x.Headers.Set("datetime", cHeader.datetime));
        //            request.UseExecute(x => x.Headers.Set("languageCode", cHeader.languageCode));
        //            request.UseExecute(x => x.Headers.Set("requestType", cHeader.requestType));
        //            request.UseExecute(x => x.Headers.Set("subscriptionId", cHeader.subscriptionId));
        //            request.UseExecute(x => x.Headers.Set("version", cHeader.version));
        //            var response = await request.GetResponse<FundtransferRes>();
        //            res = response.Message;
        //        }

        //        //string rvat = await saveUniqueIdGiditalDb(req.digitalTranId, long.Parse(res.data.uniqueId), res.data.tranId, cHeader);
        //        return res;
        //    }
        //    catch (Exception ex)
        //    {

        //        // APILog.LogError(System.Reflection.MethodBase.GetCurrentMethod()?.Name, cHeader.uuid, ex, "internalTransfers Execution error ");
        //        //  APILog.LogError(System.Reflection.MethodBase.GetCurrentMethod().Name, cHeader.uuid, ex, "ERROR");

        //        return res;
        //    }
        //}


        public IDbConnection GetConnection()
        {
            var connectionString = configuration.GetSection("ConnectionStrings").GetSection("DMAIN").Value;
            var conn = new OracleConnection(connectionString);
            return conn;
        }

    }
}
