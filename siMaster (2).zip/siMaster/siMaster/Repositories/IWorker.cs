﻿using System.Threading;
using System.Threading.Tasks;

namespace siMaster.Repositories
{
    public interface IWorker
    {
        Task DoWork(CancellationToken cancellationToken);
    }
}
