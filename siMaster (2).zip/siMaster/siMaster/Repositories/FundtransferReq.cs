﻿namespace siMaster.Repositories
{
    public class FundtransferReq
    {
    }
}