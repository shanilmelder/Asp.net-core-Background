﻿namespace siMaster.Repositories
{
    public class FundtransferRes
    {
    }
}