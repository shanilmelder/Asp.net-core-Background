﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace siMaster.Models
{
    public class FundTranferRequest
    {
        public string cif { get; set; }
        public string sourceAccountNumber { get; set; }
        public string creditAccountNumber { get; set; }
        public decimal amount { get; set; }
        public decimal serviceCharge { get; set; }
        public string currencyCode { get; set; }
        public string payeeId { get; set; }
        public string payeeName { get; set; }
        public string paymentScheduleType { get; set; }
        public string modeOfOperation { get; set; }
        public string isJoint { get; set; }
        public string tranType { get; set; }
        public string tranCode { get; set; }
        public string schmType { get; set; }
        public string deviceid { get; set; }
        public string sourceTrnParticular { get; set; }
        public string payeeTrnParticular { get; set; }
        public string remarks { get; set; }


    }
}
