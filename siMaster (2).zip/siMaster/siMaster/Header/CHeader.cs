﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace siMaster.Header
{
    public class CHeader
    {
        [FromHeader]
        public string uuid { get; set; }
        [FromHeader]
        public string username { get; set; }
        [FromHeader]
        public string channel { get; set; }
        [FromHeader]
        public string version { get; set; }
        [FromHeader]
        public string datetime { get; set; }
        [FromHeader]
        public string requestType { get; set; }
        [FromHeader]
        public string languageCode { get; set; }
        [FromHeader]
        public string subscriptionId { get; set; }

    }
}
